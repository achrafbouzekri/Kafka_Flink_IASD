/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.myorg.quickstart;

import org.apache.flink.api.java.tuple.*;

import org.apache.flink.api.common.functions.JoinFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.JsonNode;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.flink.streaming.api.TimeCharacteristic;

import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
	import org.apache.flink.streaming.api.functions.timestamps.AscendingTimestampExtractor;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;

import java.util.ArrayList;
import java.util.Properties;
//JSON de test
import org.apache.flink.streaming.util.serialization.JSONKeyValueDeserializationSchema;
import org.apache.flink.table.sources.tsextractors.TimestampExtractor;
import scala.Serializable;
//import org.json.simple.parser.*;


/**
 * Skeleton for a Flink Streaming Job.
 *
 * <p>For a tutorial how to write a Flink streaming application, check the
 * tutorials and examples on the <a href="https://flink.apache.org/docs/stable/">Flink Website</a>.
 *
 * <p>To package your application into a JAR file for execution, run
 * 'mvn clean package' on the command line.
 *
 * <p>If you change the name of the main class (with the public static void main(String[] args))
 * method, change the respective entry in the POM.xml file (simply search for 'mainClass').
 */



public class StreamingJob {


	public static void main(String[] args) throws Exception {
		// set up the streaming execution environment


		final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);


//		Test streamjob = new Test();
		ArrayList<String> liste_topics = new ArrayList<String>();
		liste_topics.add("clicks");
		liste_topics.add("displays");

		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", "localhost:9092");
		properties.setProperty("zookeeper.connect", "localhost:2181");
		properties.setProperty("group.id", "test");

		//************************************************* Création de Stream *********************************************************
			DataStreamSource<ObjectNode> stream = env
		.addSource(new FlinkKafkaConsumer010<>(liste_topics, new JSONKeyValueDeserializationSchema(true), properties));



		//************************************************* Pattern de nombre de machine par userId basé sur les displays et clicks***********************************************

		// L'utilisateur ici, utilise plusieurs machines simultanément afin de se connecter au serveur et le surcharger, c'est donc un premier cas de fraude



		DataStream<Tuple3<String,String, Integer>> uid_ip = stream.map(x -> new Tuple3<String, String, Integer>(x.findValue("uid").textValue(), x.findValue("ip").textValue(), 1)).returns(new TypeHint<Tuple3<String,String,Integer>>(){}.getTypeInfo());
		DataStream<Tuple3<String,String, Integer>> uid_ip_traited = (DataStream<Tuple3<String, String, Integer>>) uid_ip.keyBy(event->event.f0).window(TumblingProcessingTimeWindows.of(Time.seconds(10))).sum(2).filter(event -> event.f2>2);


				//		reduce((x, y) -> new Tuple3<String,String, Integer>(x.f0,x.f1,x.f2+y.f2)).filter(x-> x.f2>= 3);


		uid_ip_traited.print();
		uid_ip_traited.writeAsText("file:///home/achraf/fluxdedonnes_flink/flink_java/quickstart/Pattern1/", FileSystem.WriteMode.OVERWRITE).setParallelism(1);


//************************************************* Pattern de nombre de machine par userId basé sur clicks pour savoir si on clique pour rendre efficace une pub (robot qui clique)***********************************************
		// L'utilisation utilise plusieurs machine afin de cliquer plusieurs fois sur une annonce (même annonce ou une annonces différentes), dans le but de soit :
		//* Surcharger le serveur comme dans le premeir cas
		//* Mieux référencer une Pub ou rendre une Pub plus pertinente car elle est cliqué plusieurs fois


		DataStream<org.apache.flink.api.java.tuple.Tuple2<String, Integer>> uid = stream.map(x -> new org.apache.flink.api.java.tuple.Tuple2<String, Integer>(x.findValue("uid").textValue(), 1)).returns(new TypeHint<org.apache.flink.api.java.tuple.Tuple2<String,Integer>>(){}.getTypeInfo());
		DataStream<Tuple2<String, Integer>> uid_traited =  uid.keyBy(event->event.f0).window(TumblingProcessingTimeWindows.of(Time.seconds(10))).sum(1).filter(event -> event.f1>4);

		uid_traited.print();
		uid_ip_traited.writeAsText("file:///home/achraf/fluxdedonnes_flink/flink_java/quickstart/Pattern2/", FileSystem.WriteMode.OVERWRITE).setParallelism(1);



//****************************************************** Pattern CTR,  nb_clicks / ImpressionId ********************************************
		// Si le nombre de clicks par rapport au nombre de fois où l'annonce à été vu est elevé alors cette dernière est considéré comme une fraude car dans le temps normal les utilisateurs clique rarement sur les annonces publicitaires
		// Ici nous allons detecter les fraudes effectué par un groupe d'individus, c'est a dire si on a beaucoup de clicks par rapport aux displays
		// Cependant, on ne peut pas ici detecter les utilisateurs malvéillant qui pourrait frauder, car ils seront cachés dans la masse


		DataStream<Tuple3<String,String,Integer>> CTR_impressionId_event = stream.map(x -> new Tuple3<String, String,Integer>(x.findValue("impressionId").textValue(), x.findValue("eventType").textValue(),1)).returns(new TypeHint<Tuple3<String,String,Integer>>(){}.getTypeInfo());

		DataStream<Tuple3<String,String,Integer>> CTR_impressionId_event_traited = CTR_impressionId_event.keyBy(0,1).window(TumblingProcessingTimeWindows.of(Time.minutes(2))).sum(2).filter(event->event.equals("clicks"));
		DataStream<Tuple3<String,String,Integer>> CTR_impressionId_traited = CTR_impressionId_event.keyBy(0).window(TumblingProcessingTimeWindows.of(Time.minutes(2))).sum(2).filter(x->x.f2 > 2);

		DataStream<Tuple5<String,Float,Integer,Integer,String>> result= CTR_impressionId_event.join(CTR_impressionId_traited)
				.where(event->event.f0).equalTo(event->event.f0)
		.window(TumblingProcessingTimeWindows.of(Time.minutes(2)))
				.apply (new JoinFunction<Tuple3<String,String,Integer>, Tuple3<String,String,Integer>,Tuple5<String,Float,Integer,Integer,String>>(){
					@Override
					public Tuple5<String,Float,Integer,Integer,String> join(Tuple3<String,String,Integer> first, Tuple3<String,String,Integer> second) {

						float coeff =(float)first.f2/second.f2;
						if(coeff > 0.3){
							Tuple5<String,Float,Integer,Integer,String> result = new Tuple5<String,Float,Integer,Integer,String>(first.f0,coeff,first.f2,second.f2,"Fraude");
							return result;
						}
						return null;

					}
				});
		result.print();
		uid_ip_traited.writeAsText("file:///home/achraf/fluxdedonnes_flink/flink_java/quickstart/Pattern3/", FileSystem.WriteMode.OVERWRITE).setParallelism(1);

		//*********************************************Premier pattern de fraude par clicks et display sur le nombre de clique par nombre total/
		// Ici nous allons détecter les individus malvéillant susceptible de frauder par rapport aux clicks sur les annonces
		// La différence avec le pattern au dessus, c'est que ici nous détectons l'individus frauduleux en lui même et n'ont pas l'effet de groupe
		// I.e exemple : Pour 1000 annonce, Si un utilisateur clicks 20 fois sur une même annonce en 10 secondes, il sera détecté ici comme frauduleux, par contre ne le sera pas dans le pattern plus haut
		// Si dans le cas où les autres utilisateurs ne clicks jamais sur l'annonce, on aura alors 20 clicks sur 1000 annonces, ce qui est négligeable et donc pas détectable dans le pattern plus haut


		//************************************************* Mappage de Stream  *********************************************************
		DataStream<Tuple4<String,String,String,Integer>> impressionId_Uid_event = stream.map(x -> new Tuple4<String, String, String,Integer>(x.findValue("uid").textValue(), x.findValue("impressionId").textValue(), x.findValue("eventType").textValue(),1)).returns(new TypeHint<Tuple4<String,String,String,Integer>>(){}.getTypeInfo());
		DataStream<Tuple4<String, String, String,Integer>> impressionId_Uid_traited = impressionId_Uid_event.keyBy(1,0).window(TumblingProcessingTimeWindows.of(Time.seconds(10))).sum(3).filter(x->x.f3>2);
		DataStream<Tuple4<String, String, String,Integer>> impressionId_Uid_event_traited = impressionId_Uid_event.keyBy(1,0,2).window(TumblingProcessingTimeWindows.of(Time.seconds(10))).sum(3).filter(x->x.f2.equals("clicks"));

/*
		DataStream<Tuple6<String,String,Float,Integer,Integer,String>> result= impressionId_Uid_traited.join(impressionId_Uid_event_traited)
				.where()
				.equalTo(1,0)
				.window(TumblingProcessingTimeWindows.of(Time.seconds(10)))
				.apply (new JoinFunction< Tuple3<String, String, Integer>, Tuple4<String,String,String,Integer>,Tuple6<String,String,Float,Integer,Integer,String>>(){
					@Override
					public Tuple6<String,String,Float,Integer,Integer,String> join(Tuple3<String, String, Integer> first, Tuple4<String,String,String,Integer> second) {

						float coeff =(float)second.t4()/first.t3();
						if(coeff > 0.3){
							Tuple6<String,String,Float,Integer,Integer,String> result = new Tuple6<String,String,Float,Integer,Integer,String>(first.f1(),first.f2(),coeff,first.f3(),second.f4(),"Fraude");
							return result;
						}
						return null;

					}
				});

		result.print();
*/

		// execute program
		env.execute("Flink Streaming Java API Skeleton");
	}
}
